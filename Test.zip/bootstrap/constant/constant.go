package constant

// var HashIDTable = []int{0, 1, 2, 3, 4, 5}
